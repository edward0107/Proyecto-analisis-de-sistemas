export interface Usuario{
    nombre?:string;
    correo?:string;
    uid?:string;
}