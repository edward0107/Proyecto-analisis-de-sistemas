export const environment = {
  production: true,
  url: 'firebase Functions url',
  firebase: {
    apiKey: "",
    authDomain: "",
    databaseURL: "",
    projectId: "",
    storageBucket: "",
    messagingSenderId: ""
    }
};
